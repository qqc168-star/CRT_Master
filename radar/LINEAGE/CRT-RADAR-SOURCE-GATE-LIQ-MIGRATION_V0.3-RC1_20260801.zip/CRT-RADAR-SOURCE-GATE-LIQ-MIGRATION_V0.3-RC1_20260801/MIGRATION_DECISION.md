# 遷移裁決

| 區塊 | 裁決 |
|---|---|
| V0.2 原始證據 | 原封保留 |
| fail-closed、schema、freshness、retry | 沿用語義，移入 V0.3 Source Gate |
| 遠端 endpoint | 移出 Runner，集中至 Source Registry |
| Binance forceOrder 路由 | `/public` → `/market` |
| 5 秒 empty window | 不再視為完整 L4，只能是連線診斷 |
| Persistent aggregate | 尚未建立，故 Live 繼續 BLOCKED |
| 正式模型／權重／門檻 | 未修改 |
| 外部操作 | 未授權、未實作 |
