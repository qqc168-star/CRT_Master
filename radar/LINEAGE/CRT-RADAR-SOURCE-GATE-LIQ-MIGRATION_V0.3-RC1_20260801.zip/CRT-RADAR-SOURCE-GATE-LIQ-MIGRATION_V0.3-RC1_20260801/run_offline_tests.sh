#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PYTHONPATH="$ROOT/src" python -m unittest -v "$ROOT/tests/test_source_gate_migration.py"
