# CRT Radar Source Gate＋Liquidation Migration V0.3-RC1

- 日期：2026-08-01
- 狀態：`CANDIDATE / UNMERGED / READ_ONLY`
- 正式父版：`CRT Master V1.9`
- 架構目標：`CRT-RADAR-E2E-001 V0.1（V1.10-RC2 候選）`與 RC3 候選譜系
- 外部操作權限：`NONE`

## 本包完成

1. 將 Binance `forceOrder` 從錯誤 `/public` 路由改為官方 `/market` 路由。
2. 建立唯一 `SOURCE_REGISTRY_V1.0.json`，active Runner 不再硬編碼遠端 endpoint。
3. 將 5 秒 Liquidation window 正式降格為 `DIAGNOSTIC_ONLY`。
4. 無持久化清算 aggregate 時，L4 必須 `BLOCKED / NONE`。
5. 建立 V1.10 AS namespace evidence envelope、payload hash、registry hash 與 idempotency key。
6. 保留原 V0.2 ZIP，不覆寫歷史證據。

## 本包尚未完成

- Persistent Liquidation Aggregator
- Live Shadow
- 六層計分與 Daily Radar E2E
- 排程／通知／交易

因此目前狀態是：

`SOURCE_GATE_OFFLINE_PASS / LIQUIDATION_ROUTE_FIXED / LIVE_BLOCKED_PENDING_AGGREGATOR`
