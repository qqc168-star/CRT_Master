"""CRT Radar source-gate migration package."""

__version__ = "0.3.0-rc1"
