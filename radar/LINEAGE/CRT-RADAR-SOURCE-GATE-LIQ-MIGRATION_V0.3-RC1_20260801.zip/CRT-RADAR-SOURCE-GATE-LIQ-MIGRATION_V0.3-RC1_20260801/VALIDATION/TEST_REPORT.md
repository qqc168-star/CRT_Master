# TEST REPORT｜V0.3-RC1

## 結果

- 新版 Source Gate 測試：`12/12 PASS`
- 舊版 V0.2 回歸重跑：`17/17 PASS`
- Python compile：`PASS`
- ZIP／Manifest：封裝後驗證
- Live WebSocket：`NOT RUN / SANDBOX DNS UNAVAILABLE`

## 新增測試重點

1. `forceOrder` 必須使用 Binance `/market` route。
2. `/public/ws/btcusdt@forceOrder` 必須被 Registry 拒絕。
3. Active Runner 不得硬編碼遠端 endpoint。
4. 連線成功但 0 events 不得充當正式 Liquidation metric。
5. 即使 probe 收到訊息，仍無 metric authority。
6. Persistent aggregate 缺失、coverage 不足或 stale 時一律 BLOCKED。
7. 完整 aggregate 只能解鎖 `OBSERVATION_ONLY / action_output: NONE`。
8. Evidence envelope 必須帶 source／AS namespace／payload hash／registry hash。
9. 相同 Snapshot 重跑的 idempotency key 必須一致。

## 官方路由依據

Binance 2026 WebSocket migration 文件將 Liquidations `<symbol>@forceOrder` 列為 Market stream，並要求使用 `/market`；舊路由在 2026-04-23 後停止提供相應 Market channel。

官方文件：
`https://developers.binance.com/en/docs/products/derivatives-trading-usds-futures/websocket-market-streams/Important-WebSocket-Change-Notice`

## 限制

本包尚未建立 Persistent Liquidation Aggregator，因此 Live L4 維持 `BLOCKED`。本包不是 Daily Radar E2E，也沒有任何交易權限。
