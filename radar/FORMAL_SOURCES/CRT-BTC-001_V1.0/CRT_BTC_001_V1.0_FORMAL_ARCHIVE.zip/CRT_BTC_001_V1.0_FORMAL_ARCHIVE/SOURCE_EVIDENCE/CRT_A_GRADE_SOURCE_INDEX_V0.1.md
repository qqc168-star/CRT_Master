# CRT_A_GRADE_SOURCE_INDEX V0.1

文件性質：CRT 正式來源定位清冊  
版本：V0.1  
日期：2026-07-21  
狀態：Review  
所屬主幹：🎯 第一顆比特幣｜CRT  
唯一正式依據：本次使用者上傳的 ZIP 套件  

## 一、任務裁決

本清冊只負責回答四件事：

1. 哪些來源已實際存在。
2. 哪些來源足以支撐正式文件恢復。
3. 哪些來源只能作歷史證據或核對線索。
4. 哪些正文仍缺失，必須維持 Recovery，不得補寫成原文。

本版不重新規劃 CRT，不重做既有成果，也不以聊天記憶替代 ZIP 正文。

## 二、A 級來源定義

A 級來源須同時符合：

- 有可讀取的實體正文或原始檔。
- 有可定位的檔名、版本或來源套件。
- 能以 SHA-256 固定內容。
- 可辨識其文件角色與適用範圍。
- 不以摘要、檔名、聊天記憶冒充完整正文。

來源等級：

- **A1｜正式現行來源**：可支撐現行治理或恢復工作。
- **A2｜正式歷史來源**：曾為正式成果，但已被新版取代；可作版本與決策追溯。
- **B｜核對線索**：內容有價值，但不足以單獨恢復正式正文。
- **GAP｜缺失項**：知道名稱或身分，尚未取得完整正文。
- **VISUAL｜視覺資產**：可支撐品牌與世界觀，不作市場事實或模型正文依據。

## 三、A 級來源總表

| Source ID | 來源套件／文件 | 等級 | 內容角色 | 可支撐恢復範圍 | 限制與裁決 |
|---|---|---:|---|---|---|
| A-001 | `CRT_Recovery_System_V1_CORE.zip` | A1 | Recovery System 核心治理包 | GOV、CURRENT_STATE、RECOVERY_CHECKLIST、HANDOFF、MASTER_INDEX、START_HERE、DECISION_LOG、CHANGELOG | 核心包內多數文件仍為 Review；可作目前治理基線，不等於全部已驗收 Active |
| A-002 | `CRT-PACK-001_成果去留表_V0.1.zip` | A1 | 成果去留裁決 | 保留、修訂、歷史保存、撤回、待恢復之分類 | 不提供 BTC、Radar、Constitution、Research 正式正文 |
| A-003 | `CRT-PACK-006_BTC-001_Recovery_V0.1.zip` | A1 | BTC-001 恢復與缺口紀錄 | 確認 BTC-001 身分、Recovery 狀態、禁止事項、驗收條件 | **不是** BTC-001 模型正文，不得改名或升格替代正文 |
| A-004 | `CRT_ARCHIVE_RESCUE_PACKAGE_V0.2.zip` | A2 | 舊歸檔救援母包 | Radar v0.99 正文、GOV V1.0、舊 HANDOFF、舊索引、BTC 恢復線索 | 含舊狀態與已被後續裁決修正的內容；須逐檔引用，不得整包視為現況 |
| A-005 | `CRT_Master_bootstrap_V0.1.zip` | A2 | Repository 初始工程骨架 | 專案結構、初始索引、狀態檔、測試模板 | 已被 Recovery System 核心骨架取代，不得覆蓋現行狀態 |
| A-006 | `CRT-GOV-001_V1.1.zip` | A1-duplicate | GOV V1.1 單檔交付件 | 與 A-001 內同名正文核對 | 與核心包內正文相同，保留作交付備份，不建立第二權威來源 |
| A-007 | `CURRENT_STATE_V0.2.zip` | A1-duplicate | CURRENT_STATE 單檔交付件 | 與 A-001 核對 | 已被 PACK-006 內 `CURRENT_STATE V0.3` 更新 |
| A-008 | `HANDOFF_V2.zip` | A1-duplicate | HANDOFF 單檔交付件 | 與 A-001 核對 | 其「下一工作」已被後續 CURRENT_STATE 更新，不支配現況 |
| A-009 | `MASTER_INDEX_V0.2.zip` | A1-duplicate | MASTER_INDEX 單檔交付件 | 與 A-001 核對 | 待本包更新為 V0.3 |
| A-010 | `RECOVERY_CHECKLIST_V1.0.zip` | A1-duplicate | 搬家驗收單檔 | 與 A-001 核對 | 保留，不重複匯入 |
| A-011 | `START_HERE_V2.zip` | A1-duplicate | 啟動入口單檔 | 與 A-001 核對 | 保留，不重複匯入 |

## 四、正式正文恢復矩陣

| 正式文件群 | 已找到來源 | 正文狀態 | 恢復判定 | 下一步 |
|---|---|---|---|---|
| BTC｜CRT-BTC-001 | A-003、A-004 僅有恢復紀錄與線索 | **完整正文未找到** | Recovery／不可執行 | 繼續尋找可信原始正文或逐字匯出檔；找到前不重建 V1.0 |
| Radar｜CRT-RADAR-001～004 | A-004 內四份 Markdown 正文 | **正文已找到** | 可進入內容核對與 V1 恢復程序 | 下一階段恢復 Radar 正文，核對 v0.99、壓力測試補丁與後續決策 |
| Constitution | 本次 ZIP 未找到正式憲法正文 | **正文未找到** | GAP | 等待使用者上傳正式憲法 ZIP／原始正文 |
| Research | 本次 ZIP 未找到研究院正式正文集合 | **正文未找到** | GAP | 等待研究文件 ZIP；逐份建立文件編號、版本、來源與驗收狀態 |
| Governance | A-001、A-002、A-003 | 正文已找到 | 可持續使用，部分仍待驗收 | 以 CURRENT_STATE 最新版統一主任務與狀態 |

## 五、Radar 已定位正文

A-004 內已實際找到：

- `CRT-RADAR-001_每日自動雷達框架_v0.99.md`
- `CRT-RADAR-002_決策紀錄_v0.99.md`
- `CRT-RADAR-003_待解問題清單_v0.99.md`
- `CRT-RADAR-004_第三次階段歸檔清冊_v0.99.md`

裁決：這四份是目前第一組可直接進入「正式正文恢復」的材料。它們仍須核對後續壓力測試與是否存在更新版本，但不再屬於「正文缺失」。

## 六、BTC-001 缺口鎖定

目前已確認：

- 正式成果名稱與版本存在。
- 恢復紀錄存在。
- 部分核心原則與指標線索存在。
- 完整章節、原始公式、門檻、版本頁與完整驗收紀錄不存在於本次 ZIP。

因此 `CRT-BTC-001` 維持：

> Recovery／正文未載入／不可執行

任何後續整理只能標記為「恢復草稿」或「候選重建稿」，不能冒充 V1.0 原文。

## 七、Constitution 與 Research 缺口

本批 ZIP 未發現：

- CRT 憲法完整正文與版本頁。
- `CRT｜終章：前行者之心` 正式匯出正文。
- CRT 前行者研究院正式文件集合。
- ETH 2026/07 熊市分析正式歸檔檔案。

這些成果可能在其他尚未上傳的 ZIP 中。現階段只登記 GAP，不依聊天摘要重建。

## 八、視覺資產登記

四張重新上傳圖像已收入本包 `visual_assets/`，分類為 VISUAL：

| Asset ID | 檔名 | 角色 | 使用限制 |
|---|---|---|---|
| V-001 | `CRT_Dashboard_Dark_Master.png` | CRT 總體控制台視覺母稿 | 圖中數字、年份與市場數據不作現行事實依據 |
| V-002 | `CRT_Near_Earth_Fortress.png` | 近地軌道基地／世界觀場景 | 品牌與封面用途 |
| V-003 | `CRT_Phase01_Foundation.png` | Recovery／Foundation 建倉視覺 | 工程階段與章節封面用途 |
| V-004 | `CRT_Dashboard_Light_Master.png` | CRT 淡色閱讀版控制台 | 圖中數字不作現行決策資料 |

## 九、去重與版本裁決

1. CORE 包中的 GOV、CURRENT_STATE、HANDOFF、MASTER_INDEX、RECOVERY_CHECKLIST、START_HERE，與各單檔 ZIP 為同內容交付形式；索引只建立一個權威條目。
2. `CRT_HANDOFF_PACKAGE_成果救援線_V0.1` 與 `CRT-PACK-000 V0.1` 屬歷史工程證據，不支配現行主任務。
3. `CRT_ARCHIVE_RESCUE_PACKAGE_V0.2` 逐檔引用；不得因母包存在而把其中所有狀態升格為 Active。
4. 最新主任務以 PACK-006 內 `CURRENT_STATE V0.3` 及本包更新後的 `CURRENT_STATE V0.4` 為準。

## 十、結論與下一個唯一工作

`CRT_A_GRADE_SOURCE_INDEX V0.1` 已建立。

恢復順位依既定任務保持：

> BTC → Radar → Constitution → Research → CRT_Master

但 BTC 正文仍缺失。依「不重建假正文」原則，下一個可實際施工的正文項目為：

> **建立 `CRT-BTC-001_SOURCE_RECOVERY_SEARCH V0.1`，持續定位 BTC 原始正文；並同時將已找到的 Radar v0.99 正文整理成待核對工作集，不提前封版。**

若使用者另行上傳 BTC、Constitution 或 Research 正式 ZIP，立即先納入本索引，再依既定順位恢復。
