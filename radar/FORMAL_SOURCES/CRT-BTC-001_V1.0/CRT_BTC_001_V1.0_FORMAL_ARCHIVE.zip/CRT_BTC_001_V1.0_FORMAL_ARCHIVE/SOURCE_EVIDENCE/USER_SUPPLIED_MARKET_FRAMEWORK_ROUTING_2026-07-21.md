# 使用者提供｜2026 BTC 築底判斷材料與跨章路由

## 原始判斷主旨

- 當前更像熊市後半段的築底期，而非已確認反轉。
- 反彈可能由空頭回補、薄流動性與試探性建倉共同推動。
- 不宜空倉死等深層價格，也不宜在反彈中滿倉。
- 深層 Realized Price／CVDD 可能因市場結構改變而未被觸及。
- 趨勢確認需核對現貨成交、Spot CVD、ETF 資金、OI、Funding、期權與週線結構。

## 各章吸收裁決

### 第三章
- 納入「深層價值錨非必達」原則。
- 保留深價路徑與高位築底路徑。
- Realized Price、CVDD 只提供價值位置，不提供最終底部證書。

### 第四章
- 納入長期持有人吸收、虧損實現、MVRV Z-Score 與投降成熟度。

### 第五章
- 納入現貨成交量、Spot CVD、ETF、OI、Funding、期權防禦與 Pi Cycle Bottom。

### 第七章
- 將「放量突破並站穩關鍵週線區」納入季節轉強確認。
- 6.8萬至7萬只作 2026 情境價格，不升格為永久門檻。

### 第八／九／十一章
- 分層投入比例與價格區只作情境案例。
- 正式比例需代入使用者最新持倉、現金、生存基金及 STRC／SATA 底盤。
- 45%／35%／20% 等主觀概率不納入核心模型。

## 來源連結（由使用者提供）

- Glassnode｜The Week On-chain Week 26, 2026
- Glassnode｜BTC Market Pulse Week 29, 2026
- Bitcoin Magazine Pro｜Why Bitcoin Might Not Reach The Realized Price Again
- Glassnode｜The Week On-chain Week 27, 2026
- CoinGlass｜BTC Futures Market Data

本檔只保存使用者提供材料的模型收穫與路由，不宣稱已重新驗證各來源即時數值。
