# CONTINUITY_RULES.md

1. 根目錄 START_HERE 是唯一入口。
2. 所有正式來源已攤平，不依賴二層 ZIP。
3. 每一章產出 Checkpoint ZIP。
4. 每三章產出 Milestone ZIP。
5. Working Body 必須包含截至當時的全部正文。
6. Checkpoint 不可只放單章。
7. 每包都要有 Current State、Section Status、Decision Log、Changelog、Handoff、SHA256。
8. 發現上下文退化，立即輸出 Emergency Checkpoint。
9. 不把新寫內容標成歷史原文。
10. 十二章完成後輸出 V1.0-RC；使用者確認後才升格 V1.0 FORMAL_ARCHIVE。

11. 第四章起，每章須先完成定位、價值、必要性與重複內容檢核，只保留可執行內容。

12. 每章交付後須完整展開正文並停在章末供使用者確認。
