# HANDOFF.md

## 文件狀態
- 文件：CRT-BTC-001｜BTC 熊市季節、價值帶與投降模型
- 版本：V1.0
- 狀態：FORMAL_ARCHIVE
- 範圍：第一至第十二章
- 驗收：AG-0 至 AG-9 全部 PASS

## 唯一真相來源
本 Final ZIP 為 CRT-BTC-001 唯一正式依據。聊天記憶、舊 Checkpoint、舊 Milestone 與 RC1 不得覆蓋本版。

## 後續工作
- 持續以 V1.0 執行點燈與實際案例驗證。
- 新發現只建立變更提案，不回寫 V1.0。
- 相容性補強進入 V1.1；破壞性改版進入 V2.0。
- 回填 CRT Master Index／主聊天室歸檔。

## 新聊天室續接
上傳本 Final ZIP，依 `START_HERE.md`、`GOVERNANCE/CURRENT_STATE.md`、`GOVERNANCE/HANDOFF.md` 讀取。
