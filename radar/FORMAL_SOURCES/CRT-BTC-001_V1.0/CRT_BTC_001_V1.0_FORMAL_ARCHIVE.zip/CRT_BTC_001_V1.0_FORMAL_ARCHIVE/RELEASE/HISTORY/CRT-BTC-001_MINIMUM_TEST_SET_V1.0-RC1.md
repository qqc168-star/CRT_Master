# CRT-BTC-001｜最低回歸測試集 V1.0-RC1

| ID | 情境 | 預期結果 | RC1 靜態檢查 |
|---|---|---|---|
| TST-01 | 深價但 S0 | 不得底部確認 | PASS |
| TST-02 | V0＋C3＋S3 高位築底 | 走高門檻例外路徑 | PASS |
| TST-03 | 價格漲、CVD 負、槓桿熱 | S1／SX | PASS |
| TST-04 | Pi Cycle 單獨觸發 | 不升 S2／S3 | PASS |
| TST-05 | C3＋S2＋E2 | 只建春季候選 | PASS |
| TST-06 | 候選後再破底 | 候選失效回冬 | PASS |
| TST-07 | C3＋S3＋E3＋獨立驗證 | 可確認春季，不滿倉 | PASS |
| TST-08 | 68K–71K | 只重新點燈 | PASS |
| TST-09 | Q4 但 C／S 未成熟 | 保持底部驗收 | PASS |
| TST-10 | 公司大幅稀釋 | 該資產 AM-X | PASS |
| TST-11 | SATA 高收益、信用不明 | 不自動買入 | PASS |
| TST-12 | 掛單租約事件 | REVIEW_REQUIRED | PASS |
| TST-13 | 第一層成交 | 重算持倉與三底線 | PASS |
| TST-14 | 指標公式衝突 | VX／DATA_CONFLICT | PASS |
| TST-15 | 平台通道事件 | R4 隔離，不永久翻季 | PASS |

本表為規則一致性的靜態回歸集。實際市場點燈須使用當時真實資料另建測試紀錄。
