# CRT-BTC-001 RELEASE RECORD

- 文件：CRT-BTC-001｜BTC 熊市季節、價值帶與投降模型
- 候選版本：V1.0-RC1
- 日期：2026-07-21
- 狀態：READY_FOR_USER_ACCEPTANCE
- 範圍：CH01–CH12
- 前一施工包：CRT_BTC_001_CHECKPOINT_11_V0.9.13
- 靜態驗收：AG-0 至 AG-8 PASS
- 使用者驗收：AG-9 PENDING
- 正式邊界：本包不是 V1.0 FORMAL_ARCHIVE

## 發布內容

- 十二章完整正文
- 全來源證據與 Recovery 基礎
- Decision Log、Changelog、Current State、Handoff
- Acceptance Matrix、Minimum Test Set、Change Request Template
- Manifest、SHA256 與 ZIP 讀取測試

## 已知限制

- 動態市場與公司資料須於每次點燈重新取得。
- 2026 時間與價格情境不是永久門檻。
- 指標須鎖定資料商、公式與更新時間。
- 本輪只完成 CRT-BTC-001，不代表整個 CRT 專案封版。

## 正式放行

使用者確認後：升格 V1.0／FORMAL_ARCHIVE，產生 Final ZIP；若有修正，產生 V1.0-RC2。
