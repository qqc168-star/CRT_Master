# CRT-BTC-001 RELEASE RECORD

- 文件：CRT-BTC-001｜BTC 熊市季節、價值帶與投降模型
- 正式版本：V1.0
- 日期：2026-07-21
- 狀態：FORMAL_ARCHIVE
- 範圍：CH01–CH12
- 前一版本：V1.0-RC1｜SUPERSEDED_BY_V1.0
- 驗收：AG-0 至 AG-9 全部 PASS

## 正式發布內容

- 十二章完整正文
- 全來源證據與 Recovery 基礎
- Decision Log、Changelog、Current State、Handoff
- Acceptance Matrix、Minimum Test Set、Change Request Template
- User Acceptance Record、Manifest、SHA256 與 ZIP 讀取測試

## 正式邊界

- 本 V1.0 為 CRT-BTC-001 唯一正式版本。
- 動態市場、公司、股息、持倉與現金資料須於每次點燈重新取得。
- 2026 時間與價格情境不是永久門檻。
- 指標須鎖定資料商、公式與更新時間。
- 本輪只完成 CRT-BTC-001，不代表整個 CRT 專案封版。
- 後續營運補強依第十二章進入 V1.1；不得靜默覆蓋 V1.0。
