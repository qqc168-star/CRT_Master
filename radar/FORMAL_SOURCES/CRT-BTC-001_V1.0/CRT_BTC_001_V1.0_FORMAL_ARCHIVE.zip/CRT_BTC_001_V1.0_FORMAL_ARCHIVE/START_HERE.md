# START_HERE.md

## 唯一任務

續建並完成：

`CRT-BTC-001｜BTC 熊市季節、價值帶與投降模型`

## 真實起點

本包沒有假裝存在「已完成前三章」。

目前正式存在的是：

1. CRT-BTC-001 的文件身分
2. Recovery Record
3. Gap Record
4. 全來源搜尋報告
5. 已確認核心原則
6. A 級來源索引
7. CRT Constitution 正式正文
8. 12 章施工骨架

因此，本工程是：

> 依已確認證據續建正式正文，不是恢復一份已完成舊正文。

## 必讀順序

1. 本檔 `START_HERE.md`
2. `SOURCE_EVIDENCE/CRT-BTC-001_RECOVERY_RECORD_V0.1.md`
3. `SOURCE_EVIDENCE/CRT-BTC-001_GAP_RECORD_V0.1.md`
4. `SOURCE_EVIDENCE/CRT-BTC-001_SOURCE_RECOVERY_SEARCH_REPORT_V0.1.md`
5. `SOURCE_EVIDENCE/CRT_A_GRADE_SOURCE_INDEX_V0.1.md`
6. `SOURCE_EVIDENCE/CRT-CONSTITUTION-001_V1.0.md`
7. `RECOVERED_FOUNDATION.md`
8. `WORKING/CRT-BTC-001_WORKING_BODY.md`
9. `WORKING/CRT-BTC-001_SECTION_STATUS.csv`
10. `GOVERNANCE/CONTINUITY_RULES.md`

## 已確認、可直接採用的核心原則

- BTC 價格是溫度，BTC 週期是季節。
- CRT 要先認季節，再來看溫度。
- 估值便宜不等於價格已止跌。
- 底部證據群至少包括：
  - CVDD
  - MVRV Z-Score
  - Pi Cycle Bottom
  - BTC 週線止跌
  - 去槓桿
  - 現貨承接
- 四季不可直接等同日曆季度。
- 舊 BTC 價格參考區不是現行死線。
- BTC、MSTR、ASST 必須相互關照。
- 正式市場判斷使用最新真實資料。

## 施工命令

直接從第 1 章開始施工。

每完成一章：

1. 先完成該章定位、價值、必要性與重複內容檢核
2. 更新完整 Working Body
3. 更新 Section Status
4. 更新 Current State
5. 更新 Decision Log
6. 更新 Changelog
7. 輸出 Checkpoint ZIP
8. 在聊天室完整展開本章正文
9. 停在章末供使用者確認

每完成三章，另輸出 Milestone ZIP。

使用者確認或輸入 `Go on` 後進入下一章。

## 停工條件

只有下列情況才能停下詢問：

- 需要使用者裁決正式模型原則
- 缺少不能從公開資料取得的必要材料
- 出現證據衝突
- 發現上下文退化症狀

其餘情況連續施工至 V1.0-RC。


## V1.0 正式入口

本包已完成十二章並通過使用者驗收，狀態為 `FORMAL_ARCHIVE`。

正式讀取順序：

1. `GOVERNANCE/CURRENT_STATE.md`
2. `GOVERNANCE/HANDOFF.md`
3. `RELEASE/CRT-BTC-001_RELEASE_RECORD_V1.0.md`
4. `RELEASE/CRT-BTC-001_ACCEPTANCE_MATRIX_V1.0.csv`
5. `WORKING/CRT-BTC-001_WORKING_BODY.md`

後續不得重做第一至十二章。新資料用於點燈與營運案例；規則修正依第十二章建立 V1.1／V2.0。
